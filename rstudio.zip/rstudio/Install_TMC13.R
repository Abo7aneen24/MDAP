#  Install_TMC_V13.R 
#  (c) wwosniok@math.uni-bremen.de

#  Truncated minimum chi-square estimation

#  For method description see:
#  W. Wosniok, R. Haeckel: A new indirect estimation of reference intervals:
#  truncated minimum chi-square (TMC) approach. 
#  https://doi.org/10.1515/cclm-2018-1341

#  For the TMC programme manual: see the manual in the 'TMC/text' directory

#  This is the TMC installation programme for installation from the TMC
#  web site https://www.math.uni-bremen.de/~c05c/TMC13_public/ . 
#  It generates the directory structure, if not already 
#  present, makes backup copy of files in the /prog directory if appropriate,
#  installs actual programme files, test data and manual. Already existing 
#  files in the backup, figs, tabs and log directory are not changed. 

#  Usage of this file:

#  - Create a directory TMC13 and copy this installation 
#    file into that directory (= the installation directory). 
#  - Open R
#  - Change the working directory to the installation directory TMC13
#    (File / Change dir) or (Datei/ Verzeichnis wechseln) 
#  - Open the installation file (this file)
#  - Run the installation file (Ctrl+a, then Ctrl+s) or (Strg+a, then Strg+s)
#    This causes the installation of TMC13. Details of the installation depend
#    on whether this is a new installation or an update of an existing 
#    installation:  
   
#  - If there is not yet a TMC13 directory in the installation directory: 
#    -- the TMC13 directory and all necessary subdirectories will be created
#    -- all programme files will be copied to TMC13/prog
#    -- the manual will be copied to TMC13/text
#    -- the test data set 'TMC13_TestData.csv' will be copied to TMC13/data   
#    -- a sample data information file 'DataFileInfoDemo.csv' will be copied
#       to TMC13/data. This file can furtheron be modified or expanded for analyses 
#       by the user. However, the line describing file no 9999 (the test data)
#       should not be removed.

#  - If there is already a TMC13 directory in the installation directory:
#    -- all files from TMC13/prog are moved to TMC13/backup/yyyy-mm-dd-HH-MM,
#       where yyyy-mm-dd-HH-MM is the date and time of day of the execution 
#       of this installation programme 
#    -- all actual programme files will be copied to TMC13/prog
#    -- the actual manual will be copied to TMC13/text
#    -- a test data set 'TMC13_test.csv' will be copied to TMC13/data   

#  -  After installation, this installation programme makes TMC13/prog the
#     working directory  

#  Installation test
#  -  Open the test file 'TMC_seg000_Start_Test.R'
#  -  Run this file (Ctrl+a, then Ctrl+s) or (Strg+a, then Strg+s). Execution 
#     time is roughly 3 minutes on a standard notebook.
#  -  The most relevant graph files produced by the installation test are 
#     TMC13_TestData_c2_oAll_dAll-F151.tmc.bmp  and 
#     TMC13_TestData_c2_oAll_dAll-F160.051.bmp . 
#     These should look like the figure on page 6 of the TMC manual.

 
#  CHANGE HISTORY
#  22.10.2022 Source directory changed to TMC13_public
#  16.05.2021 Start
# ==========================================================================

# ==========================================================================
#  Begin of version-dependent entries
# ==========================================================================

#  Directory  *from which* to install 
#  The installation file contains a subdirectory structure, which will be 
#  copied to the target directory if it does not yet exist.  
input.path <- "http://www.math.uni-bremen.de/~c05c/TMC13_public_2022-11-15/" 

#  Name of the TMC manual
manual.file <- "TMC13_Manual_2022-11-15.pdf"

# ==========================================================================
#  End of version-dependent entries
# ==========================================================================

# =================================================================
#  Start execution
# =================================================================

# Target path is the present working directory
target.path <- paste(getwd(), "/", sep="")

cat("\n TMC will be installed from         ", input.path, 
    "\n TMC will be installed in directory ", target.path, "\n")

# ---------------------------------------------------------------------------
#  Check if required directory structure already exists. Look only for 
#  folder "prog", assuming that all directories exist if this directory exists 

if (!dir.exists("prog"))
{ 
  # ---------------------------------------------------------------------------
  # Directory does not exist, create the complete directory structure
  dir.create(paste(target.path, "backup", sep="")) 
  dir.create(paste(target.path, "data", sep="")) 
  dir.create(paste(target.path, "figs", sep="")) 
  dir.create(paste(target.path, "figs/1_stra", sep="")) 
  dir.create(paste(target.path, "figs/2_file", sep="")) 
  dir.create(paste(target.path, "figs/3_scen", sep="")) 
  dir.create(paste(target.path, "log", sep="")) 
  dir.create(paste(target.path, "prog", sep="")) 
  dir.create(paste(target.path, "tabs", sep="")) 
  dir.create(paste(target.path, "tabs/1_stra", sep="")) 
  dir.create(paste(target.path, "tabs/2_file", sep="")) 
  dir.create(paste(target.path, "tabs/3_scen", sep="")) 
  dir.create(paste(target.path, "temp", sep="")) 
  dir.create(paste(target.path, "text", sep="")) 
  bu.path <- NA
} else
{
  # -------------------------------------------------------------------------
  # Directory exists, make backup copy of existing programme files
  datetime <- date()  #  "Mon Jun 29 18:32:48 2020"
                      #            111111111122222 
                      #   123456789012345678901234
                       
  dt <- paste(substr(datetime, 21, 24),
              substr(datetime,  5,  7),
              substr(datetime,  9, 10),
              substr(datetime, 12, 13),
              substr(datetime, 15, 16),
              substr(datetime, 18, 19), sep="-")

  bu.path <- paste(target.path, "backup/", dt, "/", sep="")
  dir.create(bu.path) 

  #  Backup all *.R files so far present in prog 
  #  Get list of existing *.R files in prog
  file.names <- dir(paste(target.path, "prog/", sep=""))

  #  Consider R files only
  files.n  <- length(file.names)
  name.len <- nchar(file.names)
  is.R     <- toupper(substr(file.names, name.len, name.len)) == "R"

  cat("\n Existing prog directory  ", paste(target.path, "prog/", sep=""),
      "\n Backup directory         ", bu.path,
      "\n Total files              ", files.n,
      "\n # of R files for backup  ", sum(is.R),
      "\n\n")

  file.names <- file.names[is.R]
  files.n    <- length(file.names)

  #  Copy programme files 
  for (fn in file.names)
  {
    ok <- file.copy(from=paste(target.path, "prog/", fn, sep=""),
                    to=paste(bu.path, fn, sep=""),
                    overwrite=TRUE, copy.date=TRUE)  
    if (ok) 
    { cat("\n  ", fn, "  backed up ") } else
    { cat("\n +++   ", fn, "   could not be backed up +++ \n") }
  }
  cat("\n\n   Backup finished \n")
}

# ---------------------------------------------------------------------------
#  Download new files. No wildcards, no directories!

#  Manual
rc <- download.file(paste(input.path, "text/", manual.file, sep=""),
                    paste(target.path, "text/", manual.file, sep=""),
                    mode="wb" )
if (rc == 0) 
{ cat("\n Manual ", manual.file, "  copied \n") } else
{ cat("\n +++  ", manual.file, "  could not be copied +++ \n") }

# ---------------------------------------------------------------------------
#  Test data
rc <- download.file(paste(input.path, "data/TMC13_TestData.csv", sep=""),
                    paste(target.path, "data/TMC13_TestData.csv", sep=""),
                    mode="wb" )
if (rc == 0) 
{ cat("\n Test data TMC13_TestData.csv copied  \n") } else
{ cat("\n +++  TMC13_TestData.csv could not be copied +++ \n") }

# ---------------------------------------------------------------------------
#  Data information file
if (is.na(bu.path))
{ rc <- download.file(paste(input.path, "data/DataFileInfoDemo.csv", sep=""),
                      paste(target.path, "data/DataFileInfoDemo.csv",
                            sep=""), mode="wb" ) 
  if (rc == 0) 
  { cat("\n Data information file copied \n") } else
  { cat("\n +++  DataFileInfo.csv could not be copied +++ \n") }
}

# ---------------------------------------------------------------------------
#  R programme files
#  Get list of filenames in the source prog directory
rc <- download.file(paste(input.path, "temp/FileList.RData", sep=""),
                    paste(target.path, "temp/FileList.RData", sep=""),
                    mode="wb" )

if (rc == 0) 
{ cat("\n filelist.RData copied  \n") } else
{ cat("\n +++  filelist.RData could not be copied +++ \n") }

load(file="temp/FileList.RData")  #  contains filelist
file.names <- filelist

#  Consider R files only
files.n  <- length(file.names)
name.len <- nchar(file.names)
is.R     <- toupper(substr(file.names, name.len, name.len)) == "R"

cat("\n Source directory       ", paste(input.path, "prog/", sep=""),
    "\n Target directory       ", paste(target.path, "prog/", sep=""),
    "\n Total files            ", files.n,
    "\n R files                ", sum(is.R),
    "\n\n")

file.names <- file.names[is.R]
files.n    <- length(file.names)

#  Copy programme files 
for (fn in file.names)
{
  rc <- download.file(paste(input.path, "prog/", fn, sep=""),
                      paste(target.path, "prog/", fn, sep=""),
                      mode="wb")
  if (rc == 0) 
  { cat("\n  ", fn, "  copied \n") } else
  { cat("\n +++   ", fn, "   could not be copied +++ \n") }
}

setwd(paste(target.path, "prog/", sep=""))

cat("\n\n  Installation finished",
      "\n  Actual working directory is", paste(target.path, "prog/", sep=""),
    "\n ====================================================================",
    "\n")

# =================================================================
# =====  Programme end  ===========================================
# =================================================================
